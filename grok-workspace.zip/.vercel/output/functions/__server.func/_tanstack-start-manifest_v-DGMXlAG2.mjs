//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DGMXlAG2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-TtpL61MF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-TtpL61MF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C0rVbK5L.js"]
	}
} });
//#endregion
export { tsrStartManifest };
