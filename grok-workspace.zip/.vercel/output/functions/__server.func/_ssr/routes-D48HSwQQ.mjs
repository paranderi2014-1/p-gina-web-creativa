import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Mail, c as Check, d as ArrowRight, i as MapPin, l as Building2, o as Landmark, r as Scale, s as Clock, t as Users, u as BookOpen } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D48HSwQQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SCREENS = [
	{
		id: "estudio",
		label: "Estudio",
		icon: Landmark
	},
	{
		id: "practicas",
		label: "Prácticas",
		icon: Scale
	},
	{
		id: "socios",
		label: "Socios",
		icon: Users
	},
	{
		id: "doctrina",
		label: "Doctrina",
		icon: BookOpen
	},
	{
		id: "clientes",
		label: "Clientes",
		icon: Building2
	},
	{
		id: "contacto",
		label: "Contacto",
		icon: MapPin
	}
];
var PRACTICES = [
	{
		num: "01",
		name: "Sociedades y Fusiones"
	},
	{
		num: "02",
		name: "Cumplimiento Normativo"
	},
	{
		num: "03",
		name: "Propiedad Intelectual"
	},
	{
		num: "04",
		name: "Litigio Corporativo"
	}
];
var PARTNERS = [
	{
		role: "Socio Director",
		scope: "Estrategia legal corporativa, gobernanza y relacionamiento institucional."
	},
	{
		role: "Socia — Fusiones y Adquisiciones",
		scope: "Due diligence, estructuración de operaciones y negociación de contratos."
	},
	{
		role: "Socio — Litigio Corporativo",
		scope: "Contencioso mercantil, arbitraje y solución de controversias comerciales."
	}
];
var ARTICLES = [
	{
		id: "reforma",
		meta: "Sociedades · Noviembre 2026",
		title: "Reforma societaria: claves para el directorio en 2027",
		body: "Cómo los nuevos requisitos de gobierno corporativo afectan a las juntas directivas y qué ajustes preparar en los estatutos.",
		image: "/studio/biblioteca.jpg",
		alt: "Biblioteca jurídica del bufete"
	},
	{
		id: "cumplimiento",
		meta: "Cumplimiento · Octubre 2026",
		title: "Programas de cumplimiento para empresas importadoras",
		body: "Elementos mínimos de un programa anticorrupción, controles de terceros y registro de operaciones sensibles.",
		image: "/studio/juntas.jpg",
		alt: "Sala de juntas corporativa con ventanales"
	},
	{
		id: "ma",
		meta: "Fusiones · Septiembre 2026",
		title: "Cláusulas de indemnización en contratos de compraventa",
		body: "Negociación de warranties, límites de responsabilidad y mecanismos de retención en transacciones de M&A.",
		image: "/studio/recepcion.jpg",
		alt: "Recepción del bufete con vista urbana"
	}
];
var CLIENTS = [
	{
		name: "Agropecuaria del Sur",
		segment: "Agroexportación"
	},
	{
		name: "Banco Meridional",
		segment: "Servicios financieros"
	},
	{
		name: "Inmobiliaria Urbana",
		segment: "Desarrollo inmobiliario"
	},
	{
		name: "Energía del Chaco",
		segment: "Energía y utilities"
	},
	{
		name: "Logística Nacional",
		segment: "Transporte y distribución"
	},
	{
		name: "Constructora Andina",
		segment: "Construcción e infraestructura"
	}
];
function LexiaApp() {
	const [screen, setScreen] = (0, import_react.useState)("estudio");
	const [theme, setTheme] = (0, import_react.useState)("navy");
	const [consulta, setConsulta] = (0, import_react.useState)(null);
	const [reading, setReading] = (0, import_react.useState)(null);
	const [sent, setSent] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = window.localStorage.getItem("lexia-theme");
		if (saved === "navy" || saved === "ivory") setTheme(saved);
	}, []);
	(0, import_react.useEffect)(() => {
		window.localStorage.setItem("lexia-theme", theme);
		document.documentElement.dataset.theme = theme;
	}, [theme]);
	function go(next, practice) {
		if (practice) {
			setConsulta(practice);
			setSent(false);
		}
		setScreen(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app",
		"data-theme": theme,
		"data-screen": screen,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "topbar",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "topbar-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "wordmark",
							type: "button",
							onClick: () => go("estudio"),
							children: ["LexIA", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Paraguay" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "top-nav",
							"aria-label": "Navegación principal",
							children: SCREENS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "nav-link",
								"aria-current": screen === item.id ? "page" : void 0,
								onClick: () => go(item.id),
								children: item.label
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "swatches",
						role: "group",
						"aria-label": "Paleta del estudio",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "swatch swatch-navy",
							"aria-label": "Paleta naval",
							"aria-pressed": theme === "navy",
							onClick: () => setTheme("navy")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "swatch swatch-ivory",
							"aria-label": "Paleta marfil",
							"aria-pressed": theme === "ivory",
							onClick: () => setTheme("ivory")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn header-cta",
						type: "button",
						onClick: () => go("contacto"),
						children: "Reunirse con un socio"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "stage",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: screen === "estudio" ? "screen screen-estudio is-on" : "screen screen-estudio",
						"aria-label": "Estudio",
						inert: screen !== "estudio",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "screen-inner",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-grid",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hero-copy",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "eyebrow",
											children: "Bufete corporativo · Asunción"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "hero-title",
											children: "Asesoría jurídica corporativa con precisión."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "lede",
											children: "Especialistas en derecho empresarial, fusiones y adquisiciones, cumplimiento normativo y litigio corporativo. Acompañamos a empresas locales e internacionales con criterio firme y discreción profesional."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "hero-actions",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "btn",
												type: "button",
												onClick: () => go("contacto"),
												children: "Consultar ahora"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "btn btn-ghost",
												type: "button",
												onClick: () => go("practicas"),
												children: "Ver áreas de práctica"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "hero-stats",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "stat",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "30+" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "años de trayectoria combinada" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "stat",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "áreas de práctica principales" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "stat",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "120+" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "operaciones corporativas asesoradas" })]
												})
											]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
									className: "photo-frame",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/studio/fachada.jpg",
										alt: "Fachada moderna del bufete en Asunción al atardecer"
									})
								})]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: screen === "practicas" ? "screen screen-practicas is-on" : "screen screen-practicas",
						"aria-label": "Prácticas",
						inert: screen !== "practicas",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "screen-inner",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "split",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "split-copy",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "section-head",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "section-label",
											children: "Prácticas"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "section-title",
											children: "Áreas de práctica"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "practice-list",
										children: PRACTICES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "practice-row",
											onClick: () => go("contacto", item.name),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "num",
													children: item.num
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "name",
													children: item.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
													className: "arrow",
													size: 18,
													strokeWidth: 1.5,
													"aria-hidden": true
												})
											]
										}) }, item.num))
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
									className: "photo-frame",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/studio/biblioteca.jpg",
										alt: "Biblioteca jurídica del bufete con estanterías y mesa de lectura"
									})
								})]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: screen === "socios" ? "screen screen-socios is-on" : "screen screen-socios",
						"aria-label": "Socios",
						inert: screen !== "socios",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "screen-inner",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "split split-photo-first",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
									className: "photo-frame",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/studio/juntas.jpg",
										alt: "Sala de juntas corporativa con ventanales y vista a la ciudad al atardecer"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "split-copy",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "section-head",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "section-label",
											children: "Socios"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "section-title",
											children: "Un equipo dirigido por socios"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "partner-cards",
										children: PARTNERS.map((partner) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "partner-card",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "role",
													children: partner.role
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "scope",
													children: partner.scope
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rule" })
											]
										}, partner.role))
									})]
								})]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: screen === "doctrina" ? "screen screen-doctrina is-on" : "screen screen-doctrina",
						"aria-label": "Doctrina",
						inert: screen !== "doctrina",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "screen-inner",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "doctrina-head",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "section-label",
									children: "Doctrina"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "section-title",
									children: "Notas y doctrina"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn btn-ghost",
									type: "button",
									onClick: () => setReading(null),
									children: "Todas las publicaciones"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "article-grid",
								children: ARTICLES.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: reading === article.id ? "article-card is-reading" : "article-card",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										className: "thumb",
										src: article.image,
										alt: article.alt
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "article-body",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "article-meta",
												children: article.meta
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: article.title }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: article.body }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "article-link",
												"aria-pressed": reading === article.id,
												onClick: () => setReading(article.id),
												children: "Leer la nota"
											})
										]
									})]
								}, article.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: screen === "clientes" ? "screen screen-clientes is-on" : "screen screen-clientes",
						"aria-label": "Clientes",
						inert: screen !== "clientes",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "screen-inner",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "section-head",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "section-label",
										children: "Clientes"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "section-title",
										children: "Sectores que confían en el estudio"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "client-grid",
									children: CLIENTS.map((client) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "client-cell",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "cname",
											children: client.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "cseg",
											children: client.segment
										})]
									}, client.name))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "client-note",
									children: "Nombres ilustrativos incluidos únicamente para la maqueta; deben reemplazarse por los clientes reales con autorización."
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: screen === "contacto" ? "screen screen-contacto is-on" : "screen screen-contacto",
						"aria-label": "Contacto",
						inert: screen !== "contacto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "screen-inner",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "contacto-main",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "contacto-copy",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "section-label",
											children: "Oficinas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "section-title",
											children: "Nuestras oficinas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "contact-info",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "contact-line",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
														size: 18,
														strokeWidth: 1.5,
														"aria-hidden": true
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Oficina principal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Asunción, Paraguay" })] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "contact-line",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
														size: 18,
														strokeWidth: 1.5,
														"aria-hidden": true
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Horario de atención" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lunes a viernes, de 8:30 a 18:30" })] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: sent ? "contact-line is-live" : "contact-line",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
														size: 18,
														strokeWidth: 1.5,
														"aria-hidden": true
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Contacto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Solicite una reunión con un socio; responderemos dentro de un día hábil." })] })]
												})
											]
										}),
										consulta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "consulta-line",
											children: ["Consulta: ", consulta]
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											className: "btn",
											type: "button",
											"aria-pressed": sent,
											onClick: () => setSent(true),
											children: [sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
												size: 16,
												strokeWidth: 1.75,
												"aria-hidden": true
											}) : null, "Solicitar una reunión"]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
									className: "photo-frame contacto-photo",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/studio/recepcion.jpg",
										alt: "Recepción y lounge del bufete con vista a la ciudad"
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
								className: "site-footer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "footer-grid",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "footer-brand",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "LexIAParaguay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "footer-blurb",
												children: "Bufete de derecho corporativo con sede en Asunción. Asesoramos a empresas en operaciones, cumplimiento y contencioso, con discreción y enfoque de negocio."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Prácticas" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: PRACTICES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => go("practicas"),
											children: item.name
										}) }, item.name)) })] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Estudio" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => go("estudio"),
												children: "El bufete"
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => go("socios"),
												children: "Socios"
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => go("doctrina"),
												children: "Doctrina"
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => go("contacto"),
												children: "Contacto"
											}) })
										] })] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Oficina principal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Asunción, Paraguay" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Lunes a viernes, 8:30–18:30" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setSent(true),
												children: "Solicitar una reunión"
											}) })
										] })] })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "footer-bottom",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 LexIAParaguay. Maqueta ilustrativa de diseño." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Los datos de contacto, clientes y artículos son de demostración y deben reemplazarse por información real." })]
								})]
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock",
				"aria-label": "Secciones",
				children: SCREENS.map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "dock-btn",
						"aria-current": screen === item.id ? "page" : void 0,
						onClick: () => go(item.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 16,
							strokeWidth: 1.6,
							"aria-hidden": true
						}), item.label]
					}, item.id);
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LexiaApp, {});
}
//#endregion
export { Home as component };
