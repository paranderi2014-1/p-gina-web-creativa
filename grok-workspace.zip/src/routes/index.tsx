import { createFileRoute } from "@tanstack/react-router";
import { LexiaApp } from "@/components/lexia-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LexiaApp />;
}
