import { useEffect, useState } from "react";
import {
  ArrowRight,
  BookOpen,
  Building2,
  Check,
  Clock,
  Landmark,
  Mail,
  MapPin,
  Scale,
  Users,
} from "lucide-react";

type ScreenId = "estudio" | "practicas" | "socios" | "doctrina" | "clientes" | "contacto";
type ThemeId = "navy" | "ivory";

const SCREENS: { id: ScreenId; label: string; icon: typeof Landmark }[] = [
  { id: "estudio", label: "Estudio", icon: Landmark },
  { id: "practicas", label: "Prácticas", icon: Scale },
  { id: "socios", label: "Socios", icon: Users },
  { id: "doctrina", label: "Doctrina", icon: BookOpen },
  { id: "clientes", label: "Clientes", icon: Building2 },
  { id: "contacto", label: "Contacto", icon: MapPin },
];

const PRACTICES = [
  { num: "01", name: "Sociedades y Fusiones" },
  { num: "02", name: "Cumplimiento Normativo" },
  { num: "03", name: "Propiedad Intelectual" },
  { num: "04", name: "Litigio Corporativo" },
];

const PARTNERS = [
  {
    role: "Socio Director",
    scope: "Estrategia legal corporativa, gobernanza y relacionamiento institucional.",
  },
  {
    role: "Socia — Fusiones y Adquisiciones",
    scope: "Due diligence, estructuración de operaciones y negociación de contratos.",
  },
  {
    role: "Socio — Litigio Corporativo",
    scope: "Contencioso mercantil, arbitraje y solución de controversias comerciales.",
  },
];

const ARTICLES = [
  {
    id: "reforma",
    meta: "Sociedades · Noviembre 2026",
    title: "Reforma societaria: claves para el directorio en 2027",
    body: "Cómo los nuevos requisitos de gobierno corporativo afectan a las juntas directivas y qué ajustes preparar en los estatutos.",
    image: "/studio/biblioteca.jpg",
    alt: "Biblioteca jurídica del bufete",
  },
  {
    id: "cumplimiento",
    meta: "Cumplimiento · Octubre 2026",
    title: "Programas de cumplimiento para empresas importadoras",
    body: "Elementos mínimos de un programa anticorrupción, controles de terceros y registro de operaciones sensibles.",
    image: "/studio/juntas.jpg",
    alt: "Sala de juntas corporativa con ventanales",
  },
  {
    id: "ma",
    meta: "Fusiones · Septiembre 2026",
    title: "Cláusulas de indemnización en contratos de compraventa",
    body: "Negociación de warranties, límites de responsabilidad y mecanismos de retención en transacciones de M&A.",
    image: "/studio/recepcion.jpg",
    alt: "Recepción del bufete con vista urbana",
  },
];

const CLIENTS = [
  { name: "Agropecuaria del Sur", segment: "Agroexportación" },
  { name: "Banco Meridional", segment: "Servicios financieros" },
  { name: "Inmobiliaria Urbana", segment: "Desarrollo inmobiliario" },
  { name: "Energía del Chaco", segment: "Energía y utilities" },
  { name: "Logística Nacional", segment: "Transporte y distribución" },
  { name: "Constructora Andina", segment: "Construcción e infraestructura" },
];

export function LexiaApp() {
  const [screen, setScreen] = useState<ScreenId>("estudio");
  const [theme, setTheme] = useState<ThemeId>("navy");
  const [consulta, setConsulta] = useState<string | null>(null);
  const [reading, setReading] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const saved = window.localStorage.getItem("lexia-theme");
    if (saved === "navy" || saved === "ivory") setTheme(saved);
  }, []);

  useEffect(() => {
    window.localStorage.setItem("lexia-theme", theme);
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  function go(next: ScreenId, practice?: string) {
    if (practice) {
      setConsulta(practice);
      setSent(false);
    }
    setScreen(next);
  }

  return (
    <div className="app" data-theme={theme} data-screen={screen}>
      <header className="topbar">
        <div className="topbar-start">
          <button className="wordmark" type="button" onClick={() => go("estudio")}>
            LexIA<span>Paraguay</span>
          </button>
          <nav className="top-nav" aria-label="Navegación principal">
            {SCREENS.map((item) => (
              <button
                key={item.id}
                type="button"
                className="nav-link"
                aria-current={screen === item.id ? "page" : undefined}
                onClick={() => go(item.id)}
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>
        <div className="swatches" role="group" aria-label="Paleta del estudio">
            <button
              type="button"
              className="swatch swatch-navy"
              aria-label="Paleta naval"
              aria-pressed={theme === "navy"}
              onClick={() => setTheme("navy")}
            />
            <button
              type="button"
              className="swatch swatch-ivory"
              aria-label="Paleta marfil"
              aria-pressed={theme === "ivory"}
              onClick={() => setTheme("ivory")}
            />
          </div>
          <button className="btn header-cta" type="button" onClick={() => go("contacto")}>
            Reunirse con un socio
          </button>
      </header>

      <main className="stage">
        <section
          className={screen === "estudio" ? "screen screen-estudio is-on" : "screen screen-estudio"}
          aria-label="Estudio"
          inert={screen !== "estudio"}
        >
          <div className="screen-inner">
            <div className="hero-grid">
              <div className="hero-copy">
                <p className="eyebrow">Bufete corporativo · Asunción</p>
                <h1 className="hero-title">Asesoría jurídica corporativa con precisión.</h1>
                <p className="lede">
                  Especialistas en derecho empresarial, fusiones y adquisiciones, cumplimiento normativo y
                  litigio corporativo. Acompañamos a empresas locales e internacionales con criterio firme y
                  discreción profesional.
                </p>
                <div className="hero-actions">
                  <button className="btn" type="button" onClick={() => go("contacto")}>
                    Consultar ahora
                  </button>
                  <button className="btn btn-ghost" type="button" onClick={() => go("practicas")}>
                    Ver áreas de práctica
                  </button>
                </div>
                <div className="hero-stats">
                  <div className="stat">
                    <b>30+</b>
                    <small>años de trayectoria combinada</small>
                  </div>
                  <div className="stat">
                    <b>4</b>
                    <small>áreas de práctica principales</small>
                  </div>
                  <div className="stat">
                    <b>120+</b>
                    <small>operaciones corporativas asesoradas</small>
                  </div>
                </div>
              </div>
              <figure className="photo-frame">
                <img
                  src="/studio/fachada.jpg"
                  alt="Fachada moderna del bufete en Asunción al atardecer"
                />
              </figure>
            </div>
          </div>
        </section>

        <section
          className={screen === "practicas" ? "screen screen-practicas is-on" : "screen screen-practicas"}
          aria-label="Prácticas"
          inert={screen !== "practicas"}
        >
          <div className="screen-inner">
            <div className="split">
              <div className="split-copy">
                <div className="section-head">
                  <p className="section-label">Prácticas</p>
                  <h2 className="section-title">Áreas de práctica</h2>
                </div>
                <ul className="practice-list">
                  {PRACTICES.map((item) => (
                    <li key={item.num}>
                      <button
                        type="button"
                        className="practice-row"
                        onClick={() => go("contacto", item.name)}
                      >
                        <span className="num">{item.num}</span>
                        <span className="name">{item.name}</span>
                        <ArrowRight className="arrow" size={18} strokeWidth={1.5} aria-hidden />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
              <figure className="photo-frame">
                <img
                  src="/studio/biblioteca.jpg"
                  alt="Biblioteca jurídica del bufete con estanterías y mesa de lectura"
                />
              </figure>
            </div>
          </div>
        </section>

        <section
          className={screen === "socios" ? "screen screen-socios is-on" : "screen screen-socios"}
          aria-label="Socios"
          inert={screen !== "socios"}
        >
          <div className="screen-inner">
            <div className="split split-photo-first">
              <figure className="photo-frame">
                <img
                  src="/studio/juntas.jpg"
                  alt="Sala de juntas corporativa con ventanales y vista a la ciudad al atardecer"
                />
              </figure>
              <div className="split-copy">
                <div className="section-head">
                  <p className="section-label">Socios</p>
                  <h2 className="section-title">Un equipo dirigido por socios</h2>
                </div>
                <ul className="partner-cards">
                  {PARTNERS.map((partner) => (
                    <li key={partner.role} className="partner-card">
                      <p className="role">{partner.role}</p>
                      <p className="scope">{partner.scope}</p>
                      <div className="rule" />
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section
          className={screen === "doctrina" ? "screen screen-doctrina is-on" : "screen screen-doctrina"}
          aria-label="Doctrina"
          inert={screen !== "doctrina"}
        >
          <div className="screen-inner">
            <div className="doctrina-head">
              <div>
                <p className="section-label">Doctrina</p>
                <h2 className="section-title">Notas y doctrina</h2>
              </div>
              <button className="btn btn-ghost" type="button" onClick={() => setReading(null)}>
                Todas las publicaciones
              </button>
            </div>
            <div className="article-grid">
              {ARTICLES.map((article) => (
                <article
                  key={article.id}
                  className={reading === article.id ? "article-card is-reading" : "article-card"}
                >
                  <img className="thumb" src={article.image} alt={article.alt} />
                  <div className="article-body">
                    <span className="article-meta">{article.meta}</span>
                    <h3>{article.title}</h3>
                    <p>{article.body}</p>
                    <button
                      type="button"
                      className="article-link"
                      aria-pressed={reading === article.id}
                      onClick={() => setReading(article.id)}
                    >
                      Leer la nota
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section
          className={screen === "clientes" ? "screen screen-clientes is-on" : "screen screen-clientes"}
          aria-label="Clientes"
          inert={screen !== "clientes"}
        >
          <div className="screen-inner">
            <div className="section-head">
              <p className="section-label">Clientes</p>
              <h2 className="section-title">Sectores que confían en el estudio</h2>
            </div>
            <div className="client-grid">
              {CLIENTS.map((client) => (
                <div key={client.name} className="client-cell">
                  <div className="cname">{client.name}</div>
                  <div className="cseg">{client.segment}</div>
                </div>
              ))}
            </div>
            <p className="client-note">
              Nombres ilustrativos incluidos únicamente para la maqueta; deben reemplazarse por los clientes
              reales con autorización.
            </p>
          </div>
        </section>

        <section
          className={screen === "contacto" ? "screen screen-contacto is-on" : "screen screen-contacto"}
          aria-label="Contacto"
          inert={screen !== "contacto"}
        >
          <div className="screen-inner">
            <div className="contacto-main">
              <div className="contacto-copy">
                <p className="section-label">Oficinas</p>
                <h2 className="section-title">Nuestras oficinas</h2>
                <div className="contact-info">
                  <div className="contact-line">
                    <MapPin size={18} strokeWidth={1.5} aria-hidden />
                    <div>
                      <b>Oficina principal</b>
                      <span>Asunción, Paraguay</span>
                    </div>
                  </div>
                  <div className="contact-line">
                    <Clock size={18} strokeWidth={1.5} aria-hidden />
                    <div>
                      <b>Horario de atención</b>
                      <span>Lunes a viernes, de 8:30 a 18:30</span>
                    </div>
                  </div>
                  <div className={sent ? "contact-line is-live" : "contact-line"}>
                    <Mail size={18} strokeWidth={1.5} aria-hidden />
                    <div>
                      <b>Contacto</b>
                      <span>Solicite una reunión con un socio; responderemos dentro de un día hábil.</span>
                    </div>
                  </div>
                </div>
                {consulta ? <p className="consulta-line">Consulta: {consulta}</p> : null}
                <button
                  className="btn"
                  type="button"
                  aria-pressed={sent}
                  onClick={() => setSent(true)}
                >
                  {sent ? <Check size={16} strokeWidth={1.75} aria-hidden /> : null}
                  Solicitar una reunión
                </button>
              </div>
              <figure className="photo-frame contacto-photo">
                <img
                  src="/studio/recepcion.jpg"
                  alt="Recepción y lounge del bufete con vista a la ciudad"
                />
              </figure>
            </div>
            <footer className="site-footer">
              <div className="footer-grid">
                <div className="footer-brand">
                  <h2>LexIAParaguay</h2>
                  <p className="footer-blurb">
                    Bufete de derecho corporativo con sede en Asunción. Asesoramos a empresas en operaciones,
                    cumplimiento y contencioso, con discreción y enfoque de negocio.
                  </p>
                </div>
                <div>
                  <h2>Prácticas</h2>
                  <ul>
                    {PRACTICES.map((item) => (
                      <li key={item.name}>
                        <button type="button" onClick={() => go("practicas")}>
                          {item.name}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h2>Estudio</h2>
                  <ul>
                    <li>
                      <button type="button" onClick={() => go("estudio")}>
                        El bufete
                      </button>
                    </li>
                    <li>
                      <button type="button" onClick={() => go("socios")}>
                        Socios
                      </button>
                    </li>
                    <li>
                      <button type="button" onClick={() => go("doctrina")}>
                        Doctrina
                      </button>
                    </li>
                    <li>
                      <button type="button" onClick={() => go("contacto")}>
                        Contacto
                      </button>
                    </li>
                  </ul>
                </div>
                <div>
                  <h2>Oficina principal</h2>
                  <ul>
                    <li>Asunción, Paraguay</li>
                    <li>Lunes a viernes, 8:30–18:30</li>
                    <li>
                      <button type="button" onClick={() => setSent(true)}>
                        Solicitar una reunión
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="footer-bottom">
                <span>© 2026 LexIAParaguay. Maqueta ilustrativa de diseño.</span>
                <span>
                  Los datos de contacto, clientes y artículos son de demostración y deben reemplazarse por
                  información real.
                </span>
              </div>
            </footer>
          </div>
        </section>
      </main>

      <nav className="dock" aria-label="Secciones">
        {SCREENS.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              className="dock-btn"
              aria-current={screen === item.id ? "page" : undefined}
              onClick={() => go(item.id)}
            >
              <Icon size={16} strokeWidth={1.6} aria-hidden />
              {item.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
